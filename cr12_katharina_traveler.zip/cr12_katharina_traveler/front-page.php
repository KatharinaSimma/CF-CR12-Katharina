<?php get_header(); ?>

<main>
    <div class="masthead">
            <div class="h-100 d-flex justify-content-center align-items-center">
                <h1 class="text-light"></h1>
            </div>
    </div>

    <div class="container my-5">

        <h2>Welcome to Mount Everest</h2>
        <p>Where you find the best content on snow and mountains. We deliver travel reports, checklist for your next journey and amazing images!</p>

        <div class="w-75 m-auto">
            <hr class="w-50 my-4">
            <blockquote class="blockquote text-center">
                <p class="mb-0">"I always take the same perspective with each new adventure. I put myself in the
                    position of being at the end of my life looking back. Then I ask myself if what I am doing is
                    important to me."</p>
                <footer class="blockquote-footer">Reinhold Messner <cite title="Source Title">Somewhere on the internet</cite>
                </footer>
            </blockquote>
            <hr class="w-50 my-4">
        </div>



    </div>

</main>








<?php get_footer(); ?>
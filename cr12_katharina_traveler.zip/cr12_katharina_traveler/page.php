<?php get_header(); ?>

<div class="container my-4">
   <div class="blog-main">
         <div class="blog-post">
            <?php if(have_posts()) : ?>
               <?php while(have_posts()) : the_post(); ?>
                  <h2 class="blog-post-title"><?php the_title(); ?></h2>
                  <p><?php the_content(); ?></p>
                  <hr>
         </div><!-- /.blog-post -->
   </div>  
   <div><?php comments_template(); ?> </div>

               <?php endwhile; ?>
            <?php else :?>
                  <p>No posts found</p> 
            <?php endif; ?>
</div>

<?php get_footer(); ?>
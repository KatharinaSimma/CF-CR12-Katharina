<?php get_header(); ?>

<div class="container">

    <h1 class="text-center">Blog</h1>

    <div class="container mt-5">
        <div class="row mb-2">
            <div class="col-md-9">
                <?php if(have_posts()) : ?>
                    <?php while(have_posts()) : the_post(); ?>

                        <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                            <div class="col p-4 d-flex flex-column position-static">
                                <strong class="d-inline-block mb-2 text-muted">World</strong>
                                <h3 class="mb-0"><?php the_title(); ?></h3>
                                <div class="mb-1 text-muted"><?php the_time('F, j, Y'); ?> by <?php the_author(); ?></div>
                                <p class="card-text mb-auto"><?php the_excerpt(); ?></p>
                                <a href="<?php the_permalink(); ?>" class="stretched-link text-muted">Continue reading ...</a>
                            </div>
                            <div class="col-8 d-none d-lg-block">
                                <?php $image =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID ), 'full'); ?>
                                <img src="<?php echo $image[0];?>" class="card-img" alt="...">
                            </div>
                        </div>

                    <?php endwhile; ?>

                <?php else :?>
                    <p>No posts found</p>
                <?php endif; ?>

            </div>

            <div class="col-3">
                <?php get_sidebar(); ?>
            </div>

        </div>
    </div>
</div>

<?php //get_sidebar('footer_widget_area'); ?>


<?php get_footer(); ?>